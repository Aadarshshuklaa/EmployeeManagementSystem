package Employee.Management.System;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class dBase {
    Connection connection;
    Statement statement;
    public  dBase(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection= DriverManager.getConnection("jdbc:mysql://localhost:3306/employeeManagement","root","1@#2@#3@#Adarsh");
            statement=connection.createStatement();

        }catch(Exception e){
            e.printStackTrace();
        }
    }

}
